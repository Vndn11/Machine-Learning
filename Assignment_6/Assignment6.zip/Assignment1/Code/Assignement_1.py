import numpy as np
import sys
import pandas as pd

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def compute_cost_with_regularization(X, y, weights, lambda_):
    m = len(y)
    z = X.dot(weights)
    h = sigmoid(z)
    term1 = y * np.log(h)
    term2 = (1 - y) * np.log(1 - h)
    cost = -np.sum(term1 + term2) / m
    reg_term = (lambda_ / (2 * m)) * np.sum(np.square(weights[1:]))
    cost += reg_term
    return cost

def compute_gradient_with_regularization(X, y, weights, lambda_):
    m = len(y)
    z = X.dot(weights)
    h = sigmoid(z)
    gradient = np.dot(X.T, (h - y)) / m
    gradient[1:] += (lambda_ / m) * weights[1:]
    return gradient

def gradient_descent(X, y, initial_weights, learning_rate, iterations, lambda_):
    weights = initial_weights
    cost_history = []
    
    for i in range(iterations):
        gradient = compute_gradient_with_regularization(X, y, weights, lambda_)
        weights -= learning_rate * gradient
        cost = compute_cost_with_regularization(X, y, weights, lambda_)
        cost_history.append(cost)
        
    return weights, cost_history

def predict(X, weights):

    z = np.dot(X, weights)
    probabilities = sigmoid(z)
    predictions = np.where(probabilities >= 0.5, 1, 0)
    return predictions

file_path="/".join(str(sys.argv[0]).split("/")[:-2])
data=pd.read_csv(str(file_path)+'/data/data12.csv')
# data=pd.read_csv(str(file_path)+'/data/data1.csv')
X = data.drop(columns=['Unnamed: 0', 'y'])
y = data['y']
n_features = X.shape[1]
learning_rate = 0.01
iterations = 300
lambda_ = 0.1  # Regularization strength

X_with_intercept = np.hstack([np.ones((X.shape[0], 1)), X])

# Initial weights (including intercept)
initial_weights = np.zeros(X_with_intercept.shape[1])
# print(X_with_intercept.shape)

optimized_weights,loss = gradient_descent(X_with_intercept, y, initial_weights, learning_rate, iterations, lambda_)
print("intercept:",optimized_weights[0])
print("Optimized weights with regularization:\n", optimized_weights[1:])
print("loss:",loss[-1])
y_pred=predict(X,optimized_weights[1:])
accuracy = np.mean(y == y_pred)
print("accuracy:",accuracy)

